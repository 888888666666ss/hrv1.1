import { DashboardLayout } from "@/components/dashboard-layout"

export default function Page() {
  return <DashboardLayout />
}
